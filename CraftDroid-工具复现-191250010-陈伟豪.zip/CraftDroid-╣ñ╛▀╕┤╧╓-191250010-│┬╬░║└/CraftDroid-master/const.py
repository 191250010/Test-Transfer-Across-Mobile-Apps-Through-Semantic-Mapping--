TEST_REPO = 'test_repo'
CONFIG_FILE = 'config.csv'
SA_INFO_FOLDER = 'sa_info'
LOG_FOLDER = 'log'
SNAPSHOT_FOLDER = 'snapshot'
# preference for staying at current state
# SAFE VALUE: 0.037 (a21-a23-b21) <= threshold <= 0.045 (a52-a55-b51)
# EXTRA_SCORE = 0.037
